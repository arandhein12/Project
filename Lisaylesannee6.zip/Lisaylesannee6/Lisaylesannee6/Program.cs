﻿using System;

namespace Lisaylesannee6
{
    class Program
    {
        static void Main(string[] args)
        {
            ///uue Pöörvärava loomine//
            Pöördvärav värav = new Pöördvärav();

            ///uue vaatleja loomine//
            Turvamees vaatleja = new Turvamees();
            värav.LisaVaatleja(vaatleja);
            //vaikimisi on värav suletud olekus//

            //alarm//
            värav.Möödu();
            //avab värava//
            värav.Münt();
            //suleb värava//
            värav.Möödu();
            //üks kord veel möödu annab alarmi ja teavitab siis//
            värav.Möödu();
            //ava värav//
            värav.Münt();
            //2x järejst münt, siis tuleb tänan//
            värav.Münt();

            Console.ReadLine();



        
        }
    }
}
