﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lisaylesannee6
{
    public class SuletudOlek : Olekud
    {
        public override void Möödu(Pöördvärav v)
        {
            v.Häire();
        }
        public override void Münt(Pöördvärav v)
        {
            v.Ava();
            v.MääraAvatuks();
        }
    }
}
