﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lisaylesannee6
{
    public abstract class Olekud

    {
        public abstract void Münt(Pöördvärav v);
        public abstract void Möödu(Pöördvärav v);
    }
}
