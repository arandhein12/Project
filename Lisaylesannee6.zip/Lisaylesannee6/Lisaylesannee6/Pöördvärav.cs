﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lisaylesannee6
{
    public class Pöördvärav
    {
        private Olekud _olek = new SuletudOlek();

        //lisasin vaatlejate listi ja meetodi et seda vaatlejat juurde panna//
        private List<Vaatleja> _vaatlejad = new List<Vaatleja>();


        //lisasin vaatlejate listi ja meetodi et seda vaatlejat juurde panna//
        public void LisaVaatleja(Vaatleja vaatleja) => _vaatlejad.Add(vaatleja);
        //iga vaatleja kohta kutsub ta siis Update meetodi välja //
        private void TeavitaVaatlejaid()
        {
            foreach (var v in _vaatlejad) v.Update();
        }
        //Suhtleb enda olekuga, kutsub välja registeeritud meetodi//
        public void Möödu() => _olek.Möödu(this);
        //Suhtleb enda olekuga, kutsub välja registeeritud meetodi//
        public void Münt() => _olek.Münt(this);
        public void Ava() => Console.WriteLine("Ava värav");

        public void Sule() => Console.WriteLine("Sule värav");
        public void Tänan() => Console.WriteLine("Tänan!");


        //Kui on alarm siis teavitab  vaatlejaid//
        public void Häire()
        {
            Console.WriteLine("Häire");
            TeavitaVaatlejaid();
        }
        public void MääraAvatuks() => _olek = new AvatudOlek();
        public void MääraSuletuks() => _olek = new SuletudOlek();

    }
}
