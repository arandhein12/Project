﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lisaylesannee6
{
 public  class Turvamees :  Vaatleja

    {
        public override void Update()
        {
            Console.WriteLine("Tuli teavitus pöördvärava häire kohta!");
        }
    }
}
