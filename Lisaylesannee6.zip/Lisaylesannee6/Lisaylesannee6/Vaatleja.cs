﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lisaylesannee6
{
  public abstract  class Vaatleja
    {
        public abstract void Update();
    }
}
